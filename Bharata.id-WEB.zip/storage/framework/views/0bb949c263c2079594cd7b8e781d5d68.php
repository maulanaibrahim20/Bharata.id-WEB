<?php $__env->startSection('content'); ?>
    
    <div class="container p-3 mx-auto">
        <div class="hidden md:block">
            
            <div class="grid grid-cols-3 gap-5">
                
                <div>
                    <img class="h-auto max-w-s mx-auto rounded" src="<?php echo e(url('foto_kost', $produk->foto1)); ?>"
                        alt="<?php echo e($produk->judul); ?>" />
                    <div class="grid grid-cols-4 mt-2">
                        <?php if($produk->foto2): ?>
                            <img class="h-10 w-20 mx-auto rounded" src="<?php echo e(url('foto_kost', $produk->foto2)); ?>"
                                alt="<?php echo e($produk->judul); ?>" data-modal-target="modal2" data-modal-toggle="modal2" />
                        <?php endif; ?>

                        <div id="modal2" tabindex="-1" aria-hidden="true"
                            class="hidden fixed inset-0 z-50 overflow-auto bg-black bg-opacity-50" x-show="open">
                            <div class="relative p-4 w-full max-w-2xl max-h-full">
                                <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                                    <div class="relative">
                                        <!-- Modal header -->
                                        <div
                                            class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                                            <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                                                Foto Kost
                                            </h3>
                                            <button type="button"
                                                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                                data-modal-hide="modal2">
                                                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                                    fill="none" viewBox="0 0 14 14">
                                                    <path stroke="currentColor" stroke-linecap="round"
                                                        stroke-linejoin="round" stroke-width="2"
                                                        d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                                </svg>
                                                <span class="sr-only">Close modal</span>
                                            </button>
                                        </div>
                                        <!-- Image -->
                                        <div class="p-4 md:p-5 space-y-4">
                                            <img class="max-w-full rounded-lg" src="<?php echo e(url('foto_kost', $produk->foto2)); ?>"
                                                alt="<?php echo e($produk->judul); ?>" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if($produk->foto3): ?>
                            <img class="h-10 w-20 mx-auto rounded" src="<?php echo e(url('foto_kost', $produk->foto3)); ?>"
                                alt="<?php echo e($produk->judul); ?>" data-modal-target="modal3" data-modal-toggle="modal3">
                        <?php endif; ?>

                        <div id="modal3" tabindex="-1" aria-hidden="true"
                            class="hidden fixed inset-0 z-50 overflow-auto bg-black bg-opacity-50" x-show="open">
                            <div class="relative p-4 w-full max-w-2xl max-h-full">
                                <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                                    <div class="relative">
                                        <!-- Modal header -->
                                        <div
                                            class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                                            <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                                                Foto Kost
                                            </h3>
                                            <button type="button"
                                                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                                data-modal-hide="modal3">
                                                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                                    fill="none" viewBox="0 0 14 14">
                                                    <path stroke="currentColor" stroke-linecap="round"
                                                        stroke-linejoin="round" stroke-width="2"
                                                        d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                                </svg>
                                                <span class="sr-only">Close modal</span>
                                            </button>
                                        </div>
                                        <!-- Image -->
                                        <div class="p-4 md:p-5 space-y-4">
                                            <img class="max-w-full rounded-lg" src="<?php echo e(url('foto_kost', $produk->foto3)); ?>"
                                                alt="<?php echo e($produk->judul); ?>" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if($produk->foto4): ?>
                            <img class="h-10 w-20 mx-auto rounded" src="<?php echo e(url('foto_kost', $produk->foto4)); ?>"
                                alt="<?php echo e($produk->judul); ?>" data-modal-target="modal4" data-modal-toggle="modal4" />

                            <div id="modal4" tabindex="-1" aria-hidden="true"
                                class="hidden fixed inset-0 z-50 overflow-auto bg-black bg-opacity-50" x-show="open">
                                <div class="relative p-4 w-full max-w-2xl max-h-full">
                                    <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                                        <div class="relative">
                                            <!-- Modal header -->
                                            <div
                                                class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                                                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                                                    Foto Kost
                                                </h3>
                                                <button type="button"
                                                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                                    data-modal-hide="modal4">
                                                    <svg class="w-3 h-3" aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg" fill="none"
                                                        viewBox="0 0 14 14">
                                                        <path stroke="currentColor" stroke-linecap="round"
                                                            stroke-linejoin="round" stroke-width="2"
                                                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                                    </svg>
                                                    <span class="sr-only">Close modal</span>
                                                </button>
                                            </div>
                                            <!-- Image -->
                                            <div class="p-4 md:p-5 space-y-4">
                                                <img class="max-w-full rounded-lg"
                                                    src="<?php echo e(url('foto_kost', $produk->foto5)); ?>"
                                                    alt="<?php echo e($produk->judul); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($produk->foto5): ?>
                            <img class="h-10 w-20 mx-auto rounded" src="<?php echo e(url('foto_kost', $produk->foto5)); ?>"
                                alt="<?php echo e($produk->judul); ?>" data-modal-target="modal4" data-modal-toggle="modal4" />
                            <div id="modal5" tabindex="-1" aria-hidden="true"
                                class="hidden fixed inset-0 z-50 overflow-auto bg-black bg-opacity-50" x-show="open">
                                <div class="relative p-4 w-full max-w-2xl max-h-full">
                                    <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                                        <div class="relative">
                                            <!-- Modal header -->
                                            <div
                                                class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                                                <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                                                    Foto Kost
                                                </h3>
                                                <button type="button"
                                                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                                                    data-modal-hide="modal5">
                                                    <svg class="w-3 h-3" aria-hidden="true"
                                                        xmlns="http://www.w3.org/2000/svg" fill="none"
                                                        viewBox="0 0 14 14">
                                                        <path stroke="currentColor" stroke-linecap="round"
                                                            stroke-linejoin="round" stroke-width="2"
                                                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                                                    </svg>
                                                    <span class="sr-only">Close modal</span>
                                                </button>
                                            </div>
                                            <!-- Image -->
                                            <div class="p-4 md:p-5 space-y-4">
                                                <img class="max-w-full rounded-lg"
                                                    src="<?php echo e(url('foto_kost', $produk->foto5)); ?>"
                                                    alt="<?php echo e($produk->judul); ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <hr class="mt-4 mb-2" />
                    
                    <div class="">
                        <h3 class="text-2xl font-normal font-semibold mb-3">Ratings</h3>
                        <div class="flex items-center space-x-2">
                            <div class="flex items-center space-x-1">
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star text-yellow-400"></i>
                            </div>
                            <button class="btn btn-outline-primary text-gray-400">Produk</button>
                        </div>
                        <div class="flex items-center space-x-2">
                            <div class="flex items-center space-x-1">
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star text-yellow-400"></i>
                            </div>
                            <button class="btn btn-outline-primary text-gray-400">Ketepatan Deskripsi</button>
                        </div>
                        <div class="flex items-center space-x-2">
                            <div class="flex items-center space-x-1">
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star-fill text-yellow-400"></i>
                                <i class="bi bi-star text-yellow-400"></i>
                            </div>
                            <button class="btn btn-outline-primary text-gray-400">Komunikasi Toko</button>
                        </div>
                    </div>
                    
                </div>
                
                
                <div class="overflow-y-auto max-h-[30rem] h-80" name='infopenting'>
                    <p class="font-normal text-2xl"><?php echo e($produk->judul); ?></p>

                    <div class="mt-1">
                        <span
                            class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                            <?php echo e($produk->tag); ?>

                        </span>
                        <span
                            class="bg-gray-300 text-gray-600 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-gray-900 dark:text-white">
                            <?php echo e($produk->alamat_kost); ?>

                        </span>
                    </div>

                    <div class="flex items-center gap-0 mt-4 mb-4">
                        <span class="font-normal font-semibold text-2xl">Rp<?php echo e($produk->perbulan); ?></span>
                        <span class="text-small">/bulan</span>
                    </div>

                    

                    <div class="mt-2">
                        <p class="font-semibold">Deskripsi</p>
                        <small class="font-normal"><?php echo nl2br(htmlentities($produk->cerita_pemilik)); ?></small>
                    </div>

                    <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-2">
                            <p class="font-semibold"><?php echo nl2br(htmlentities($facility->type)); ?></p>
                            <small class="font-normal"><?php echo nl2br(htmlentities($facility->facility)); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="mt-2">
                        <p class="font-semibold"><?php echo nl2br(htmlentities($rules->type)); ?></p>
                        <small class="font-normal"><?php echo nl2br(htmlentities($rules->rule)); ?></small>
                    </div>

                    <div class="mt-2">
                        <p class="font-semibold">Ketentuan Pengajuan Sewa</p>
                        <small class="font-normal"><?php echo nl2br(htmlentities($produk->ketentuan_pengajuan_sewa)); ?></small>
                    </div>

                    <div
                        class="mt-3 max-w-sm p-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <div class="container grid grid-cols-2 items-center justify-between">
                            <div class="flex gap-2 items-center">
                                <img src="https://flowbite.com/docs/images/examples/image-1@2x.jpg"
                                    class="rounded-full w-10 h-10 border" alt="profil mitra" />
                                <div class="flex flex-col gap-0">
                                    <span class="font-normal font-semibold"><?php echo e($produk->member->nama_depan); ?></span>
                                    <small class="text-gray-400">Online 2 jam lalu</small>
                                </div>
                            </div>
                            <div class="flex justify-end">
                                <a href="" class="bg-blue-500 text-white px-3 py-1 rounded-md">Follow</a>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                <div class="flex justify-end">
                    <div
                        class="max-w-xs p-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                        <p class="font-normal mb-4">Atur jumlah sewa dan catatan</p>
                        <form>
                            <p class="block text-sm font-medium text-gray-700">Periode Sewa</p>
                            <div class="mb-4 flex gap-3 items-center">
                                <input type="date" id="start_date" name="start_date"
                                    class="mt-1 block w-full border-gray-300 px-1 py-1 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                -
                                <input type="date" id="end_date" name="end_date"
                                    class="mt-1 block w-full border-gray-300 px-1 py-1 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                            </div>
                            <div class="mb-4 flex items-center">
                                <label for="quantity" class="block text-sm font-medium text-gray-700">Jumlah
                                    Barang</label>
                                <div class="flex items-center px-3">
                                    <button type="button"
                                        class="w-full bg-blue-500 text-white text-center px-4 py-2 hover:bg-blue-600 focus:outline-none focus:bg-blue-600 rounded-l-lg"
                                        onclick="decrement()">-</button>
                                    <input type="text" id="quantity" name="quantity" min="1" value="0"
                                        class="w-16 bg-gray-50 text-center border border-gray-300 text-gray-900 text-sm focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 text-center rounded-none">
                                    <button type="button"
                                        class="w-full bg-blue-500 text-white text-center px-4 py-2 hover:bg-blue-600 focus:outline-none focus:bg-blue-600 rounded-r-lg"
                                        onclick="increment()">+</button>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label for="address" class="block text-sm font-medium text-gray-700">Alamat</label>
                                <textarea id="address" name="address"
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"></textarea>
                            </div>
                            <div class="mb-4">
                                <label for="extras" class="block text-sm font-medium text-gray-700">Extras</label>
                                <div class="flex items-center gap-2">
                                    <input type="checkbox" id="extras" name="extras"
                                        class="mt-1 border-gray-300 rounded shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                                    <span>Additional driver</span>
                                </div>
                            </div>
                            <hr class="mb-3" />
                            <div class="mb-4">
                                <p class="font-medium">Harga Sewa: Rp<?php echo e($produk->perbulan); ?></p>
                                <p class="font-medium">Total: Rp<?php echo e($produk->perbulan); ?></p>
                            </div>
                            <div>
                                <button type="submit"
                                    class="w-full bg-blue-500 text-white px-4 py-2 rounded-full hover:bg-blue-600 focus:outline-none focus:bg-blue-600">
                                    Tambah ke Keranjang
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
            </div>
            
            
            <div>
                <div>
                    <h3 class="font-normal font-semibold text-2xl">Ulasan</h3>
                </div>
                <div
                    class="mt-3 max-w-xl p-4 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                    
                    
                    <div class="flex items-center gap-2">
                        <img src="https://flowbite.com/docs/images/carousel/carousel-3.svg" alt="FOTO ULASAN USER"
                            class="rounded-full w-10 h-10 border" />
                        <div class="flex flex-col gap-0">
                            <span class="font-normal font-semibold">Anwar Musyadad <span
                                    class="font-normal text-gray-400 text-xs">22-04-2024</span></span>
                            <small class="font-normal text-gray-400"><?php echo e($review->review); ?></small>
                        </div>
                    </div>
                    
                    
                    </hr>
                    
                    
                    
                </div>
            </div>
            
            <hr class="my-4" />
            
            <div>
                <h3 class="font-normal font-semibold text-2xl">Produk Serupa</h3>
                <div class="mt-3 grid grid-cols-4 gap-4">
                    <?php $__currentLoopData = $kost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('home/produk/' . $items->id)); ?>" class="w-full max-w-m p-3">
                            <div>
                                <img src="<?php echo e(url('foto_kost', $items->foto1)); ?>" class="h-auto max-w-full rounded-lg" />
                            </div>
                            <div class="mt-1">
                                <span
                                    class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                                    <?php echo e($items->tag); ?>

                                </span>
                            </div>
                            <div class="mt-1">
                                <p class="font-normal"><?php echo e(Str::limit($items->judul, 50)); ?></p>
                                <p class="text-sm font-normal font-semibold"><?php echo e($items->alamat_kost); ?></p>
                                <p class="text-sm font-normal text-gray-600"><?php echo e(Str::limit($items->cerita_pemilik, 50)); ?>

                                </p>
                                <div>
                                    <span class="text-lg font-normal  font-semibold">Rp<?php echo e($items->perbulan); ?></span><span
                                        class="text-sm">/bulan</span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
        </div>
        <div name='hp' class="block md:hidden">
            COMING SOON
        </div>
    </div>
    
    <br />
    <br />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
    <script>
        function increment() {
            var input = document.getElementById('quantity');
            input.value = parseInt(input.value) + 1;
        }

        function decrement() {
            var input = document.getElementById('quantity');
            input.value = parseInt(input.value) - 1;
            if (input.value < 1) {
                input.value = 1;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bharata.id-WEB\resources\views/home/produk/index.blade.php ENDPATH**/ ?>