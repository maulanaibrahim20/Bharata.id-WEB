<!-- BOOTSTRAP CSS -->
<link id="style" href="{{ url('/assets') }}/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

<!-- STYLE CSS -->
<link href="{{ url('/assets') }}/css/style.css" rel="stylesheet" />
<link href="{{ url('/assets') }}/css/plugins.css" rel="stylesheet" />

<!--- FONT-ICONS CSS -->
<link href="{{ url('/assets') }}/css/icons.css" rel="stylesheet" />
