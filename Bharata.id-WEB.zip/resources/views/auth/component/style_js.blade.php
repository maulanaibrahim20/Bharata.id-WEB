<!-- JQUERY JS -->
<script src="{{ url('/assets') }}/js/jquery.min.js"></script>

<!-- BOOTSTRAP JS -->
<script src="{{ url('/assets') }}/plugins/bootstrap/js/popper.min.js"></script>
<script src="{{ url('/assets') }}/plugins/bootstrap/js/bootstrap.min.js"></script>

<!-- SPARKLINE JS -->
<script src="{{ url('/assets') }}/js/jquery.sparkline.min.js"></script>

<!-- CHART-CIRCLE JS -->
<script src="{{ url('/assets') }}/js/circle-progress.min.js"></script>

<!-- Perfect SCROLLBAR JS-->
<script src="{{ url('/assets') }}/plugins/p-scroll/perfect-scrollbar.js"></script>

<!-- INPUT MASK JS -->
<script src="{{ url('/assets') }}/plugins/input-mask/jquery.mask.min.js"></script>

<!-- Color Theme js -->
<script src="{{ url('/assets') }}/js/themeColors.js"></script>

<!-- swither styles js -->
<script src="{{ url('/assets') }}/js/swither-styles.js"></script>

<!-- CUSTOM JS -->
<script src="{{ url('/assets') }}/js/custom.js"></script>
