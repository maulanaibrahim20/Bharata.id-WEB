@extends('home.index')
@section('content')
    REGISTRASI MEMBER
@endsection
